<?php
$result = array();
