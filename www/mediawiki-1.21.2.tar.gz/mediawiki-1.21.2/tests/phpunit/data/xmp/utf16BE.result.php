<?php

$result = array(
	'xmp-exif' =>
		array(
			'DigitalZoomRatio' => '0/10',
		),
	'xmp-general' =>
		array(
			'Label' => '􊯍'
		),
);
